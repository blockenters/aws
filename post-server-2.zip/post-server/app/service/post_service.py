
from sqlalchemy.orm import Session
from fastapi import HTTPException, status, UploadFile
from app.db.database import execute_delete, execute_insert, execute_query, execute_update
from app.service.s3_service import s3_service

class PostService :
    def __init__(self, db:Session):
        self.db = db

    async def delete_post(self, post_id, current_user) :
        # 1. 포스트 아이디로, 실제 포스트가 있는지 가져온다.
        sql = """select *
                from posts
                where id = :post_id ;"""
        post_result = execute_query(sql, {"post_id" : post_id})
        if not post_result :
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN)
                
        # 2. image_url에 해당하는 이미지를 S3에서 삭제
        post = post_result[0]
        s3_service.delete_file(post[3])
        # 3. DB에서 삭제
        sql = """delete from posts 
                where id = :post_id ;"""
        execute_delete(sql, {'post_id' : post_id})
        return {'status' : 'success'}


    async def update_post(self, post_id, title, content, image, current_user):
        # 1. 포스트 아이디로, 실제 포스트가 있는지 가져온다.
        sql = """select *
                from posts
                where id = :post_id ;"""
        post_result = execute_query(sql, {"post_id" : post_id})
        if not post_result :
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN)

        # 2. 내 포스트가 맞는지 확인 
        post = post_result[0]
        if post[4] != current_user['id'] :
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN)

        image_url = post[3]
        # 3. 데이터 업데이트
        # 3-1. 이미지가 있으면, 기존 이미지는 삭제하고 새 이미지 업로드        
        if image is not None:
            # 기존 이미지 삭제
            s3_service.delete_file(post[3])
            # 새 이미지를 업로드.
            image_url = await s3_service.upload_file(image)            
            
        # 3-2. db에 업데이트 
        sql = """update posts 
            set title = :title, content = :content, image_url= :image_url
            where id = :post_id ;"""
        execute_update(sql, {'title':title, 
                             'content':content, 
                             'image_url':image_url,
                             'post_id' : post_id})
        return {'status' : 'success'}

    def get_user_posts(self, current_user, page, size):

        sql = """SELECT * 
                FROM posts
                where user_id = :user_id
                order by created_at desc
                limit :size offset :offset ;"""
        
        offset = ( int(page) - 1) * int(size)
        
        posts_result = execute_query(sql, 
                      {"user_id":current_user['id'] , "offset":offset, "size":int(size) })
        
        posts = []
        for post in posts_result:
            posts.append( {
                "id" : post[0], 
                "title" : post[1],
                "content" : post[2],
                "image_url" : post[3],
                "user_id" : post[4],
                "created_at" : post[5],
                "updated_at" : post[6]
                } )

        return posts

    async def create_post(self, title, content, image, current_user):
        """포스트 생성"""
        # 1. S3에 이미지 업로드 
        image_url = await s3_service.upload_file(image)

        # 2. image_url이 있으니까, db에 인서트 한다.
        sql = """insert into posts
                (title, content, image_url, user_id)
                values
                ( :title , :content, :image_url, :user_id);"""
        execute_insert(sql, {"title":title, 
                             "content": content,
                               "image_url" : image_url,
                                "user_id" :  current_user['id']  })
        # 3. 리턴
        return {'status' : 'success'}
