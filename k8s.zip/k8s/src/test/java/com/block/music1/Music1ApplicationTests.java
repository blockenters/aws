package com.block.music1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Music1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
